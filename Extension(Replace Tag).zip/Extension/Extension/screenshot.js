function setScreenshotUrl(url) {
    document.getElementById('target').src = url;
}
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('print').addEventListener('click', function () {
        window.print();                                             // Print preview
        window.PPClose = true;
    });
});

