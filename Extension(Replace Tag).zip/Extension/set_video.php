<?php
$code = 'var allFrames;'.
'if (window.location.href.search("https://edition.cnn.com/videos") == 0) {'.
  'allFrames = document.getElementsByClassName("media__video--thumbnail")[0].parentNode;'.
'} else if (window.location.href.search("https://www.msn.com/en-us/video") == 0) {'.
  'allFrames = document.getElementsByClassName("video_player")[0].parentNode;'.
'} else if (window.location.href.search("https://www.yahoo.com/news/") == 0) {'.
  'Frames = document.getElementsByClassName("VideoPlayer");'.
  'console.log(Frames.length);'.
  'for(var i = 0;Frames.length;i++){'.
    'Frames[i].parentNode.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
    '}'.
'}else if (window.location.href.search("https://www.bloomberg.com/made") == 0) {'.
  'allFrames = document.getElementsByClassName("video-player")[0].parentNode;'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'} else if (window.location.href.search("https://www.huffpost.com/section/video") == 0) {'.
  'allFrames = document.getElementsByClassName("vdb_player")[0].parentNode;'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.

'}else if (window.location.href.search("https://www.washingtonpost.com/video/") == 0) {'.
  'allFrames = document.getElementsByClassName("powa-pane")[0].parentNode;'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.huffpost.com/entry") == 0) {'.
  'allFrames = document.getElementsByClassName("vdb_player")[0].parentNode;'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.bloomberg.com/news") == 0) {'.
  'allFrames = document.getElementsByClassName("video-player")[0].parentNode;'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.huffpost.com") == 0) {'.
  'allFrames = document.getElementsByClassName("o2-cvs-player-wrapper")[0].childNodes[0];'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.cnbc.com/") == 0) {'.
  'allFrames = document.getElementById("Continuous-PlaceHolder");'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://time.com") == 0) {'.
  'allFrames = document.getElementsByClassName("jumpstart-video")[0].parentNode.parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.cnet.com/videos") == 0) {'.
  'allFrames = document.getElementById("player-area");'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.usatoday.com/videos/") == 0) {'.
  'allFrames = document.getElementById("mainContainer");'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.cnet.com") == 0) {'.
  'allFrames = document.getElementsByClassName("responsiveListingFeatures type-videos")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.forbes.com/sites") == 0) {'.
  'allFrames = document.getElementsByClassName("video-title-container")[0].parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://nypost.com/video") == 0) {'.
  'allFrames = document.getElementsByClassName("video-container")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://nypost.com") == 0) {'.
  'allFrames = document.getElementsByClassName("s2nFloatParams")[0].parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("www.nbcnews.com") == 0) {'.
  'allFrames = document.getElementsByClassName("s2nFloatParams")[0].parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.bloomberg.com") == 0) {'.
  'allFrames = document.getElementsByClassName("video-player")[0].parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.

'}else if (window.location.href.search("https://www.independent.co.uk") == 0) {'.
  'allFrames = document.getElementsByClassName("hero-one-dmpu position-left")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.nydailynews.com") == 0) {'.
  'allFrames = document.getElementsByClassName("crd crd--cnt")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.today.com") == 0) {'.
  'allFrames = document.getElementsByClassName("video-package__video-wrapper")[0].parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.yahoo.com/video") == 0) {'.
  'allFrames = document.getElementById("Col1-0-VideoLead-Proxy");'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("http://www.hollywood.com/movies") == 0) {'.
  'allFrames = document.getElementsByClassName("td-post-text-content hw-type-video")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://deadline.com/video") == 0) {'.
  'allFrames = document.getElementsByClassName("pmc-a-grid-item pmc-a-span2@tablet")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.

'}else if (window.location.href.search("https://www.foxnews.com/") == 0) {'.
  'allFrames = document.getElementsByClassName("m video-player")[0].parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;height:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.usatoday.comdsd/") == 0) {'.
  'allFrames = document.getElementsByClassName("unselectable")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;height:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://video.foxnews.com") == 0) {'.
  'allFrames = document.getElementsByClassName("video-player video-expanded")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.businessinsider.in/videos/advertising") == 0) {'.
  'allFrames = document.getElementById("player");'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.huffingtonpost.in/entry") == 0) {'.
  'allFrames = document.getElementsByClassName("inner-floating-container")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.theguardian.com/politics/video") == 0) {'.
  'allFrames = document.getElementsByClassName("u-responsive-ratio u-responsive-ratio--hd youtube-media-atom youtube-related-videos")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.theguardian.com") == 0) {'.
  'allFrames = document.getElementsByClassName("fc-item__video-container")[0].parentNode;'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://abcnews.go.com/live/video") == 0) {'.
  'allFrames = document.getElementById("mobileHero_wrapper");'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://abcnews.go.com") == 0) {'.
  'allFrames = document.getElementsByClassName("headlines-li video tr-video")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.wsj.com/video/series") == 0) {'.
  'allFrames = document.getElementsByClassName("video-player")[0];'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'} else if (window.location.href.search("https://www.wsj.com/video") == 0) {'.
  'allFrames = document.getElementById("wrapper-player").parentNode;'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}else if (window.location.href.search("https://www.wsj.com") == 0) {'.
    'allFrames = document.getElementsByClassName("WSJTheme--video-center--kKxmSmrr ")[0];'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
  '}else if (window.location.href.search("https://www.aol.com/video/playlist") == 0) {'.
    'allFrames = document.getElementsByClassName("vdb_player ")[0];'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
  '}else if (window.location.href.search("https://www.aol.com") == 0) {'.
    'allFrames = document.getElementById("cw-right");'.
  'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
'}';
echo $code;  