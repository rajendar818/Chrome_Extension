chrome.runtime.onInstalled.addListener(function(){
	chrome.declarativeContent.onPageChanged.removeRules(undefined, function(){
		chrome.declarativeContent.onPageChanged.addRules([{
			conditions: [
				new chrome.declarativeContent.PageStateMatcher({
					pageUrl: {hostContains: 'etsy.com'}
				})
			],
			actions: [new chrome.declarativeContent.ShowPageAction()]
		}]);
	});
	var isExtensionOn = true;
	chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
	    if (request.cmd == "setOnOffState") {
	        isExtensionOn = request.data.value;
	    }

	    if (request.cmd == "getOnOffState") {
	        sendResponse(isExtensionOn);
	    }

	    if(request.cmd == "startExecution"){
	    	if(isExtensionOn){
		    	chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
				    if(tabs[0]){
						chrome.tabs.executeScript(tabs[0].id, {
							file: "/js/addElements.js"
						});
				    }
				});
		    }
	    }
	})
})