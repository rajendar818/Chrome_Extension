function setOff(){
	// set it to off
	disableButton.setAttribute('data-status', "off");
	disableButton.classList.remove("enabled");
	isExtensionOn = false;
	chrome.extension.sendMessage({ cmd: "setOnOffState", data: { value: isExtensionOn } });
}
function setOn(){
	// set it to onn
	disableButton.setAttribute('data-status', "on");
	disableButton.classList.add("enabled");
	isExtensionOn = true;
	chrome.extension.sendMessage({ cmd: "setOnOffState", data: { value: isExtensionOn } });
}
function getState(){
	// change button state to user option
	chrome.extension.sendMessage({cmd: "getOnOffState"}, function(response){
		if(response){
			setOn();
		} else{
			setOff();
		}
	});
}
getState();
var disableButton = document.getElementById("disableButton");
disableButton.onclick = function(){
	if(disableButton.getAttribute('data-status') == "on"){
		setOff();
	} else{
		setOn();
	}
}
