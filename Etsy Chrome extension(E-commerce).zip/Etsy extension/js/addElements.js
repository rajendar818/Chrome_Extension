var productsSelector = document.getElementsByClassName('block-grid-item');
var itemsData = [];
var products = [];
if(!counter){
	var counter = 0;
	document.head.innerHTML += "<style>.new-data{padding:0;margin:0}.new-data>li{list-style-type: none;padding:0;}.ul-popup{display: none; position: absolute; left: 0%; top: 100%;width: 600px; max-width: 100%;box-shadow:0 0 30px 0 rgba(0, 0, 0, 0.5); border-radius: 5px; background-color: #2196F3; padding:50 !important;list-style: none; z-index: 99999;}.ul-popup > li{lis-style-type: none !important} .ul-popup a {color: #FFF !important;text-decoration: none !important;padding: 5px 0 !important;border-bottom: 1px solid rgba(0,0, 0, 0.1) !important;display: block !important;border-radius: 0 !important;text-align: left !important;}</style>";
}
var willRemove = [];
for(var i = 0; i < productsSelector.length; i++){
	if(productsSelector[i].querySelector("a") && productsSelector[i].querySelector("a").href.match(/[a-zA-Z]+[:][\/][\/][a-zA-Z.]+[\/][\w]+[\/][\d]+/)){
		products.push(productsSelector[i]);
		productsSelector[i].innerHTML += '<div class="loading"><img src="' + chrome.extension.getURL('/img/spinner16.gif') + '"></div>';
	}
}
document.body.onclick = function(e){
	for(var elm of document.querySelectorAll(".ul-popup")){
		if(e.path.indexOf(elm) != -1){
			elm.style.display = 'block';
		} else{
			elm.style.display = 'none';
		}
	}
	var ulElm = document.getElementById(e.target.getAttribute("data-ul"));
	if(ulElm){
		e.preventDefault();
		ulElm.style.display = "block";
	}
}
getData(counter);
function getData(i){
	if(products[i]){
		if(XMLHttpRequest){
			var xhr = new XMLHttpRequest();
		} else if(ActiveXObject("Msxml2.XMLHTTP")){
			var xhr = new ActiveXObject("Msxml2.XMLHTTP");
		}  else if(ActiveXObject("Microsoft.XMLHTTP")){
			var xhr = new ActiveXObject("MIcrosoft.XMlHTTP");
		}
		if(xhr){
			xhr.onreadystatechange = function(){
				if(this.status == 200 && this.readyState == 4){
					var newDoc = document.createElement("div");
					newDoc.style.display = "none";
					newDoc.innerHTML = this.response.replace(/src=((['][^']*['])|(["][^"]*["]))/igm, "").replace(/<link[^>]*>/igm, "");
					if(products[i].querySelector(".loading")){
						products[i].querySelector(".loading").remove();
					}
					products[i].classList.add("position-relative");
					products[i].innerHTML += '<ul class="new-data">\
						<li>' + ((newDoc.querySelector("#listing-page-cart .flag-body")) ? newDoc.querySelector("#listing-page-cart .flag-body").innerHTML.match(/[^\d]+[\d]+/)[0].replace(".", ":") : '0 wanna buy this') + '</li>\
						<li>' + ((newDoc.querySelector(".listing-page-favorites-link")) ? newDoc.querySelector(".listing-page-favorites-link").innerHTML : "no favorite") + '</li>\
						<li>' + ((newDoc.querySelector("ul.list-inline.text-smaller.text-gray-lightest.mb-md-5 > .list-inline-item")) ? newDoc.querySelector("ul.list-inline.text-smaller.text-gray-lightest.mb-md-5 > .list-inline-item").innerHTML : "Date: unknown") + '</li>\
					</ul>\
					<a class="btn-view-popup" href="#" data-ul="ul-popup-' + i + '">More..</a>\
					<ul id="ul-popup-' + i + '" class="ul-popup">\
						<li>' + ((newDoc.querySelector("ul.listing-tag-list.col-xs-12.mt-md-5.pl-md-0")) ? '<ul class="listing-tag-list col-xs-12">' + newDoc.querySelector("ul.listing-tag-list.col-xs-12.mt-md-5.pl-md-0").innerHTML + '</ul>' : "No Tags") + '</li>\
						<li>' + ((newDoc.querySelector(".shipping-cost.text-gray.mb-xs-1")) ? newDoc.querySelector(".shipping-cost.text-gray.mb-xs-1").innerHTML : "Price: unkown") + '</li>\
					</ul>';
					newDoc.remove();
					var newLInk = products[i].querySelector("a").href.match(/[a-zA-Z]+[:][\/][\/][a-zA-Z.]+[\/][\w]+[\/][\d]+/);
					products[i].querySelector("a").href = newLInk ? newLInk : products[i].querySelector("a").href;
					counter ++
					getData(counter);
				}
			}
			xhr.open("GET", products[i].querySelector("a").href.match(/[a-zA-Z]+[:][\/][\/][a-zA-Z.]+[\/][\w]+[\/][\d]+/));
			xhr.send();
		}
	}
}