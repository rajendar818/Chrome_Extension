if(chrome.extension){
	chrome.extension.sendMessage({ cmd: "startExecution" });
}